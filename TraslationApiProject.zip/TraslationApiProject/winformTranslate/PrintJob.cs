﻿using System;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;

namespace winformTranslate
{
    public class PrintJob
    {
        private PrintDocument PrintDocument;
        private Graphics graphics;

        private int InitialHeight = 360;

        public PrintJob()
        {
            // this.order = order;
            //this.shop = shop;
            AdjustHeight();
        }

        /// <summary>
        ///  source code link
        ///  https://stackoverflow.com/questions/28096578/writing-nice-receipt-in-c-sharp-wpf-for-printing-on-thermal-printer-pos
        /// </summary>
        private void AdjustHeight()
        {
            var capacity = 5 * 100;
            InitialHeight += capacity;

            capacity = 5 * 100;
            InitialHeight += capacity;
        }

        public void Print(string printername)
        {
            PrintDocument = new PrintDocument();
            PrintDocument.PrinterSettings.PrinterName = printername;

            PrintDocument.PrintPage += new PrintPageEventHandler(FormatPage);
            PrintDocument.Print();
        }

        private void DrawAtStart(string text, int Offset)
        {
            int startX = 10;
            int startY = 5;
            Font minifont = new Font("Arial", 5);

            graphics.DrawString(text, minifont,
                     new SolidBrush(Color.Black), startX + 5, startY + Offset);
        }

        private void InsertItem(string key, string value, int Offset)
        {
            Font minifont = new Font("Arial", 5);
            int startX = 10;
            int startY = 5;

            graphics.DrawString(key, minifont,
                         new SolidBrush(Color.Black), startX + 5, startY + Offset);

            graphics.DrawString(value, minifont,
                     new SolidBrush(Color.Black), startX + 130, startY + Offset);
        }

        private void InsertHeaderStyleItem(string key, string value, int Offset)
        {
            int startX = 10;
            int startY = 5;
            Font itemfont = new Font("Arial", 6, FontStyle.Bold);

            graphics.DrawString(key, itemfont,
                         new SolidBrush(Color.Black), startX + 5, startY + Offset);

            graphics.DrawString(value, itemfont,
                     new SolidBrush(Color.Black), startX + 130, startY + Offset);
        }

        private void DrawLine(string text, Font font, int Offset, int xOffset)
        {
            int startX = 10;
            int startY = 5;
            graphics.DrawString(text, font,
                     new SolidBrush(Color.Black), startX + xOffset, startY + Offset);
        }

        private void DrawSimpleString(string text, Font font, int Offset, int xOffset)
        {
            int startX = 10;
            int startY = 5;
            graphics.DrawString(text, font,
                     new SolidBrush(Color.Black), startX + xOffset, startY + Offset);
        }

        private void FormatPage(object sender, PrintPageEventArgs e)
        {
            graphics = e.Graphics;
            Font minifont = new Font("Arial", 5);
            Font itemfont = new Font("Arial", 6);
            Font smallfont = new Font("Arial", 8);
            Font mediumfont = new Font("Arial", 10);
            Font largefont = new Font("Arial", 12);
            int Offset = 10;
            int smallinc = 10, mediuminc = 12, largeinc = 15;
            int startX = 10;
            int startY = 5;

            //Image image = Resources.logo;
            //e.Graphics.DrawImage(image, startX + 50, startY + Offset, 100, 30);

            graphics.DrawString("Welcome to TARIQ Confectionary Shop", smallfont,
                  new SolidBrush(Color.Black), startX + 22, startY + Offset);

            Offset = Offset + largeinc + 10;

            String underLine = "-------------------------------------";
            DrawLine(underLine, largefont, Offset, 0);

            Offset = Offset + mediuminc;
            DrawAtStart("Invoice Number: " + 55, Offset);
            var customerName = "Imran farooqi";
            if (!String.Equals(customerName, "N/A"))
            {
                Offset = Offset + mediuminc;
                DrawAtStart("Customer: " + customerName, Offset);
            }
            var address = "ab z ahd hh";
            if (!String.Equals(address, "N/A"))
            {
                Offset = Offset + mediuminc;
                DrawAtStart("Address: " + address, Offset);
            }
            var phone = "025458852";
            if (!String.Equals(phone, "N/A"))
            {
                Offset = Offset + mediuminc;
                DrawAtStart("Phone # : " + phone, Offset);
            }

            Offset = Offset + mediuminc;
            DrawAtStart("Date: " + System.DateTime.Now, Offset);

            Offset = Offset + smallinc;
            underLine = "-------------------------";
            DrawLine(underLine, largefont, Offset, 30);

            Offset = Offset + largeinc;

            InsertHeaderStyleItem("Name. ", "Price. ", Offset);

            var name = "Chips";
            var quntity = 4;
            var cvalue = "4";

            Offset = Offset + largeinc;
            for (int i = 0; i < 10; i++)
            {
                InsertItem(name + " x " + quntity, cvalue, Offset);
                Offset = Offset + smallinc;
            }

            /* foreach (var itran in order.ItemTransactions)
             {
                 InsertItem(itran.Item.Name + " x " + itran.Quantity, itran.Total.CValue, Offset);
                 Offset = Offset + smallinc;
             }*/
            /*foreach (var dtran in order.DealTransactions)
            {
                InsertItem(dtran.Deal.Name, dtran.Total.CValue, Offset);
                Offset = Offset + smallinc;

                foreach (var di in dtran.Deal.DealItems)
                {
                    InsertItem(di.Item.Name + " x " + (dtran.Quantity * di.Quantity), "", Offset);
                    Offset = Offset + smallinc;
                }
            }*/

            underLine = "-------------------------";
            DrawLine(underLine, largefont, Offset, 30);

            Offset = Offset + largeinc;
            InsertItem(" Net. Total: ", cvalue, Offset);

            Offset = Offset + smallinc;
            // cash value
            InsertItem(" Discount: ", cvalue, Offset);

            /* if (!order.Cash.Discount.IsZero())
             {
                 Offset = Offset + smallinc;
                 InsertItem(" Discount: ", order.Cash.Discount.CValue, Offset);
             }*/

            Offset = Offset + smallinc;
            // gross total
            InsertHeaderStyleItem(" Amount Payable: ", cvalue, Offset);

            Offset = Offset + largeinc;
            // string address2 = "dukan ka address";
            DrawSimpleString("Address: " + address, minifont, Offset, 15);

            Offset = Offset + smallinc;
            String number = "Tel: " + "02022222245" + " - OR - " + 02596585;
            DrawSimpleString(number, minifont, Offset, 35);

            Offset = Offset + 7;
            underLine = "-------------------------------------";
            DrawLine(underLine, largefont, Offset, 0);

            Offset = Offset + mediuminc;
            String greetings = "Thanks for visiting us.";
            DrawSimpleString(greetings, mediumfont, Offset, 28);

            Offset = Offset + mediuminc;
            underLine = "-------------------------------------";
            DrawLine(underLine, largefont, Offset, 0);

            Offset += (2 * mediuminc);
            string tip = "TIP: -----------------------------";
            InsertItem(tip, "", Offset);

            Offset = Offset + largeinc;
            string DrawnBy = "M-Tech Solutions: 0302-2916847 - OR - 03133310719";
            DrawSimpleString(DrawnBy, minifont, Offset, 15);
        }
    }
}